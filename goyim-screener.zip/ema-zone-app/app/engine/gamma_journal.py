"""Forward test of the gamma take-profit / stop levels.

Option chains from Public only show today, so gamma levels can't be backtested over past years.
Instead every alert's gamma plan is saved here on the day it's sent, and checked against the
daily bars that come after it: which hit first, the take profit or the stop?
"""
from datetime import date, datetime

from . import store

FILE = "gamma_plans.json"
MAX_KEEP = 1000


def add(ticker, plan, source, day=None):
    """Record one plan (skips a repeat for the same ticker + day + source)."""
    if not plan or not (plan.get("tp") or plan.get("sl")):
        return
    day = day or date.today().isoformat()
    rows = store.load(FILE, []) or []
    if any(r["ticker"] == ticker and r["date"] == day and r["source"] == source for r in rows):
        return
    rows.append({"ticker": ticker, "date": day, "source": source, "entry": plan["entry"],
                 "tp": (plan.get("tp") or {}).get("price"), "tp_why": (plan.get("tp") or {}).get("why"),
                 "sl": (plan.get("sl") or {}).get("price"), "sl_why": (plan.get("sl") or {}).get("why"),
                 "rr": plan.get("rr"), "regime": plan.get("regime"),
                 "saved": datetime.now().isoformat(timespec="seconds")})
    store.save(FILE, rows[-MAX_KEEP:])


def walk(row, bars):
    """Outcome of one plan from the bars after its date. Stop and target on the same day = stop (cautious)."""
    import pandas as pd

    idx = bars.index.tz_convert(None) if bars.index.tz is not None else bars.index
    after = bars[idx.normalize() > pd.Timestamp(row["date"])]
    entry, tp, sl = row["entry"], row.get("tp"), row.get("sl")
    for k, (d, b) in enumerate(after.iterrows()):
        if sl and b["low"] <= sl:
            px = min(b["open"], sl)
            return {"result": "stop", "exit": round(float(px), 2), "exit_date": str(d.date()), "days": k + 1,
                    "ret": round((px / entry - 1) * 100, 2)}
        if tp and b["high"] >= tp:
            px = max(b["open"], tp)
            return {"result": "target", "exit": round(float(px), 2), "exit_date": str(d.date()), "days": k + 1,
                    "ret": round((px / entry - 1) * 100, 2)}
    last = float(after["close"].iloc[-1]) if len(after) else entry
    hi = float(after["high"].max()) if len(after) else entry
    lo = float(after["low"].min()) if len(after) else entry
    return {"result": "open", "days": len(after), "ret": round((last / entry - 1) * 100, 2),
            "best": round((hi / entry - 1) * 100, 2), "worst": round((lo / entry - 1) * 100, 2)}


def evaluate(get_bars, limit=300):
    rows = (store.load(FILE, []) or [])[-limit:]
    out, errors = [], []
    for r in rows:
        try:
            b = get_bars(r["ticker"])
            out.append({**r, **walk(r, b)})
        except Exception as e:
            errors.append(f"{r['ticker']}: {e}")
            out.append({**r, "result": "no data"})
    done = [x for x in out if x["result"] in ("target", "stop")]
    summ = {"plans": len(out), "closed": len(done), "open": sum(1 for x in out if x["result"] == "open")}
    if done:
        summ["target_pct"] = round(100 * sum(1 for x in done if x["result"] == "target") / len(done), 1)
        summ["avg_ret"] = round(sum(x["ret"] for x in done) / len(done), 2)
        summ["avg_days"] = round(sum(x["days"] for x in done) / len(done), 1)
    rr = [x["rr"] for x in out if x.get("rr") is not None]
    if rr:
        summ["avg_rr"] = round(sum(rr) / len(rr), 2)
    return {"summary": summ, "rows": list(reversed(out)), "errors": errors[:5]}
